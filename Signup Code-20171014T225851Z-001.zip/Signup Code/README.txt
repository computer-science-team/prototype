Signup Page was updated on 10/11
Changes: Updated signup.html with css to look better
Changes done By: Dharmik Pandya, 10/11/2017, 9:46 PM

Signup Page was updated on 10/14
Changes: connected to database
Changes done By: Yousuf Ahmed, 10/14/2017, 5:10 PM
